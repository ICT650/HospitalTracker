package com.example.hospitaltracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class about_us extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
    }
}