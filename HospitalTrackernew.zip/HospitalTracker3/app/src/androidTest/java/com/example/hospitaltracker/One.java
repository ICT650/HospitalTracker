package com.example.hospitaltracker;

public class One {
}
