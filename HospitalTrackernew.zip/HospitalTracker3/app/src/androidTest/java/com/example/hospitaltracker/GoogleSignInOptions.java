package com.example.hospitaltracker;

public class GoogleSignInOptions {
}
