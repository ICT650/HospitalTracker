package com.example.hospitaltracker;

public class ApplicationCompat {
}
